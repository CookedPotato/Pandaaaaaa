using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Player : MonoBehaviour
{

    public GameObject losePanel;
    public GameObject timeText;

    public Text healthDisplay;
    

    public float speed;
    private float input;

    Rigidbody2D rb;
    Animator anim;
    AudioSource source;

    public int health;
    public int totalTime = 60;

    // Start is called before the first frame update
    void Start()
    {
        // source = GetComponent<AudioSource>();
        anim = GetComponent<Animator>();
        rb = GetComponent<Rigidbody2D>();
        healthDisplay.text = health.ToString();
        StartCoroutine(CountDown());
    }
	
    private void Update()
    {
        if (input != 0)
        {
            anim.SetBool("isRunning", true);
        }
        else {
            anim.SetBool("isRunning", false);
        }
	
        //if (input > 0)
        //{
        //    transform.eulerAngles = new Vector3(0, 0, 0);
        //}
        //else if (input < 0) {
        //    transform.eulerAngles = new Vector3(0, 180, 0);
        //}
        
    }
	
    // Update is called once per frame
    void FixedUpdate()
    {
        // Storing player's input
        input = Input.GetAxisRaw("Horizontal");

        // Moving player
        rb.velocity = new Vector2(input * speed, rb.velocity.y);
      
    }

    public void TakeDamage(int damageAmount) {
        // source.Play();
        health = health - damageAmount < 0 ? 0 : health - damageAmount;
        healthDisplay.text = health.ToString();

        if (health <= 0) {
            // losePanel.SetActive(true);
            Destroy(gameObject);
        }
    }

    IEnumerator CountDown()
    {
        while (totalTime >= 0) {
            timeText.GetComponent<Text>().text = totalTime.ToString();
            yield return new WaitForSeconds(1);
            totalTime--;
            if (totalTime <= 0) {
            // losePanel.SetActive(true);
            Destroy(gameObject);
        }
        }
    }

}
