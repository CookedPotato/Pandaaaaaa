﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawner : MonoBehaviour
{

    public Transform[] spawnPoints;
    public GameObject[] hazards;
	public GameObject[] ingredients;

    private float timeBtwSpawns;
    public float startTimeBtwSpawns;

    public float minTimeBetweenSpawns;
    public float decrease;

    public GameObject player;

    public int foodindex1;
    public int foodindex2;


    // Update is called once per frame
    void Update()
    {
        if (player != null)
        {
            if (timeBtwSpawns <= 0)
            {
				// Choose the spawn point.
                Transform randomSpawnPoint = spawnPoints[Random.Range(0, spawnPoints.Length)];

				// The ratio of possibility of dropping attacks and ingredients is 5:1.
                GameObject randomHazard = null;
				int isAttack = Random.Range(0, 6);
				if (isAttack < 5)
					randomHazard = hazards[Random.Range(0, hazards.Length)];
				else
                    //randomHazard = ingredients[Random.Range(0, ingredients.Length)];
                    randomHazard = ingredients[Random.Range(foodindex1, foodindex2)];

                Instantiate(randomHazard, randomSpawnPoint.position, Quaternion.identity);

                if (startTimeBtwSpawns > minTimeBetweenSpawns)
                {
                    startTimeBtwSpawns -= decrease;
                }

                timeBtwSpawns = startTimeBtwSpawns;

             }
            else
            {
                timeBtwSpawns -= Time.deltaTime;
            }
        }
    }
}
