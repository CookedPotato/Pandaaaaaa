﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

public class LevelControl : MonoBehaviour
{
    public GameObject note;
    public Button[] levels;
    public Text noteText;
    SceneSwitcher ss;
    // Start is called before the first frame update
    void Start()
    {
        Save savedData = readData();
        for (int i = 0; i < levels.Length; i++)
        {
            if (savedData.unlocked[i])
            {
                levels[i].GetComponent<Button>().onClick.AddListener(switchScene);
            }
            else
            {
                levels[i].GetComponent<Button>().onClick.AddListener(alert);
            }
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void switchScene()
    {
        ss = levels[0].GetComponent<SceneSwitcher>();
        ss.PlayGame();
    }

    public void alert()
    {
        noteText.text = "You shall not pass!\n Uhhhhhh ------  I want to eat\n STEAMED EGGPLANT(蒜蓉蒸茄子). \n_(:зゝ∠)_.";
        noteText.color = Color.white;
        note.SetActive(true);
    }

    public void close()
    {
        note.SetActive(false);
    }

    public Save readData()
    {
        BinaryFormatter bf = new BinaryFormatter();
        FileStream OldFile = File.Open(Application.persistentDataPath + "/gamesave.save", FileMode.Open);
        Save OldData = (Save)bf.Deserialize(OldFile);
        OldFile.Close();

        return OldData;
    }
}
